const axios = require('axios');
const { cmd } = require('../command');
const config = require('../config');

cmd({
    pattern: "repo",
    alias: ["git", "sc", "script"],
    desc: "Fetch the bot repository details",
    category: "main",
    react: "👑",
    filename: __filename
},
async (conn, mek, m, { from, reply, sender }) => {
    try {
        const repoUrl = "https://github.com/jampanxdm-creator/JAMPAN-XMD";
        const apiUrl = "https://api.github.com/repos/jampanxdm-creator/JAMPAN-XMD";
        
        // Fetching real-time data from GitHub
        const response = await axios.get(apiUrl);
        const data = response.data;

        let repoMsg = `👑 *JAMPAN-XMD REPO DETAILS* 👑

✨ *Repository Name:* ${data.name}
👤 *Owner:* ${data.owner.login}
⭐ *Stars:* ${data.stargazers_count}
🍴 *Forks:* ${data.forks_count}
📅 *Last Updated:* ${new Date(data.updated_at).toLocaleDateString()}

🔗 *Repo Link:* ${repoUrl}

> *Created by 𝖩𝖺𝗆𝗉𝖺𝗇47* 👨‍💻`;

        // Define the fakevCard (jampan tz)
        const fakevCard = {
            key: {
                fromMe: false,
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast"
            },
            message: {
                contactMessage: {
                    displayName: "Popkid Ke",
                    vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:𝖩𝖺𝗆𝗉𝖺𝗇47\nORG:𝖩𝖺𝗆𝗉𝖺𝗇47;\nTEL;type=CELL;type=VOICE;waid=255674229015:+255674229015\nEND:VCARD`
                }
            }
        };

        // Clean context info (Removed externalAdReply)
        const newsletterContextInfo = {
            mentionedJid: [sender],
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: config.NEWSLETTER_JID || '120363423997837331@newsletter',
                newsletterName: config.OWNER_NAME || 'JAMPAN-XMD',
                serverMessageId: 1
            }
        };

        // Sending image with caption and context, but no ad reply
        await conn.sendMessage(from, {
            image: { url: `https://files.catbox.moe/hjauxb.png` },
            caption: repoMsg,
            contextInfo: newsletterContextInfo
        }, { quoted: fakevCard });

    } catch (e) {
        console.log(e);
        reply("❌ Error fetching repository details. Please try again later.");
    }
});
