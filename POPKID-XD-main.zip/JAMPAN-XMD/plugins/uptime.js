const { cmd } = require('../command');
const config = require('../config');

cmd({
    pattern: "uptime",
    alias: ["runtime", "status"],
    desc: "Check how long the bot has been running.",
    category: "main",
    filename: __filename
}, async (conn, m, mek, { from, sender, reply }) => {
    try {
        // Calculate uptime
        const uptimeSeconds = process.uptime();
        const hours = Math.floor(uptimeSeconds / 3600);
        const minutes = Math.floor((uptimeSeconds % 3600) / 60);
        const seconds = Math.floor(uptimeSeconds % 60);

        // iOS Style Text Formatting
        const uptimeString = `*ꜱʏꜱᴛᴇᴍ ʀᴜɴᴛɪᴍᴇ* ⏳\n\n*ᴜᴘᴛɪᴍᴇ:* ${hours}ʜ ${minutes}ᴍ ${seconds}ꜱ\n*ꜱᴛᴀᴛᴜꜱ:* Active 🟢`;

        // iOS-style vCard (Sleek & Professional)
        const iosvCard = {
            key: {
                fromMe: false,
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast"
            },
            message: {
                contactMessage: {
                    displayName: " JAMPAN-XMD",
                    vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:𝗃𝖺𝗆𝗉𝖺𝗇-𝗑𝖽𝗆\nTEL;type=CELL;type=VOICE;waid=255674229015:+255674229015\nEND:VCARD`
                }
            }
        };

        // iOS Newsletter Context (Clean, No Large Image)
        const iosContext = {
            mentionedJid: [sender],
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: config.NEWSLETTER_JID || '120363423997837331@newsletter',
                newsletterName: "ᴊᴀᴍᴘᴀɴ-xᴍᴅ ɴᴇᴛᴡᴏʀᴋ",
                serverMessageId: 1
            },
            externalAdReply: {
                title: " ᴊᴀᴍᴘᴀɴ ꜱʏꜱᴛᴇᴍꜱ",
                body: "ᴍᴏɴɪᴛᴏʀɪɴɢ ʟɪᴠᴇ ꜱᴇꜱꜱɪᴏɴ...",
                mediaType: 1,
                renderLargerThumbnail: false, // Removes the big black image
                thumbnailUrl: "https://files.catbox.moe/ncnfg0.png", // Small icon style
                sourceUrl: "https://whatsapp.com/channel/0029Vb8DGUCDDmFTDzBKDf2j"
            }
        };

        // Send reaction
        await conn.sendMessage(from, { react: { text: "⏳", key: mek.key } });

        // Send uptime with the minimalist context and quoted vCard
        await conn.sendMessage(from, { 
            text: uptimeString, 
            contextInfo: iosContext 
        }, { quoted: iosvCard });

    } catch (e) {
        console.log(e);
        reply(`❌ Error: ${e.message}`);
    }
});
